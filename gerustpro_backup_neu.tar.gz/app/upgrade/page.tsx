export default function UpgradePage() {
  return (
    <main
      style={{
        maxWidth: 980,
        margin: '0 auto',
        padding: '1rem',
        color: 'var(--text)',
        overflowX: 'hidden',
      }}
    >
      <h1
        style={{
          fontSize: 44,
          fontWeight: 950,
          margin: 0,
          color: 'var(--text)',
          wordBreak: 'break-word',
        }}
      >
        Upgrade your Daily Log Builder
      </h1>

      <p
        style={{
          marginTop: 10,
          color: 'var(--muted)',
          fontWeight: 900,
          lineHeight: 1.5,
          maxWidth: '70ch',
        }}
      >
        Get unlimited projects, advanced PDF reports, and cloud backup.
      </p>

      <div
        style={{
          display: 'grid',
          gap: 14,
          marginTop: 18,
        }}
      >
        <div
          style={{
            border: '1px solid var(--border)',
            background: 'var(--chip)',
            borderRadius: 18,
            padding: 18,
          }}
        >
          <div
            style={{
              display: 'inline-block',
              border: '1px solid var(--border)',
              background: 'rgba(255,255,255,.04)',
              padding: '6px 10px',
              borderRadius: 999,
              fontWeight: 950,
              color: 'var(--muted)',
              marginRight: 8,
            }}
          >
            Free Plan
          </div>

          <div
            style={{
              fontSize: 40,
              fontWeight: 950,
              margin: '14px 0 10px',
            }}
          >
            $0{' '}
            <span
              style={{
                fontSize: 16,
                color: 'var(--muted)',
                fontWeight: 900,
              }}
            >
              /mo
            </span>
          </div>

          <ul
            style={{
              margin: 0,
              paddingLeft: 18,
              color: 'var(--text)',
              fontWeight: 900,
              lineHeight: 1.9,
            }}
          >
            <li>✓ Basic Daily Logs</li>
            <li>✓ Photo Uploads (Limited)</li>
            <li>✓ Limited Projects</li>
          </ul>

          <div
            style={{
              marginTop: 14,
              width: '100%',
              minHeight: 44,
              borderRadius: 14,
              fontWeight: 950,
              border: '1px solid var(--border)',
              background: 'rgba(255,255,255,.04)',
              color: 'rgba(255,255,255,.55)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'not-allowed',
            }}
          >
            Current Plan
          </div>
        </div>

        <div
          style={{
            border: '1px solid rgba(255,255,255,.22)',
            background: 'rgba(255,255,255,.08)',
            borderRadius: 18,
            padding: 18,
          }}
        >
          <div
            style={{
              display: 'inline-block',
              border: '1px solid rgba(255,255,255,.22)',
              background: 'rgba(255,255,255,.10)',
              padding: '6px 10px',
              borderRadius: 999,
              fontWeight: 950,
              color: 'var(--text)',
              marginRight: 8,
            }}
          >
            POPULAR
          </div>

          <div
            style={{
              display: 'inline-block',
              border: '1px solid var(--border)',
              background: 'rgba(255,255,255,.04)',
              padding: '6px 10px',
              borderRadius: 999,
              fontWeight: 950,
              color: 'var(--muted)',
            }}
          >
            Pro Plan
          </div>

          <div
            style={{
              fontSize: 40,
              fontWeight: 950,
              margin: '14px 0 10px',
            }}
          >
            $19{' '}
            <span
              style={{
                fontSize: 16,
                color: 'var(--muted)',
                fontWeight: 900,
              }}
            >
              /mo
            </span>
          </div>

          <ul
            style={{
              margin: 0,
              paddingLeft: 18,
              color: 'var(--text)',
              fontWeight: 900,
              lineHeight: 1.9,
            }}
          >
            <li>✓ Unlimited Projects</li>
            <li>✓ Advanced PDF Export</li>
            <li>✓ Priority Support</li>
            <li>✓ Team Collaboration</li>
          </ul>

          <button
            type="button"
            onClick={() => alert('Later: connect Stripe / payments')}
            style={{
              marginTop: 14,
              width: '100%',
              minHeight: 44,
              borderRadius: 14,
              fontWeight: 950,
              border: '1px solid rgba(255,255,255,.22)',
              background: 'rgba(255,255,255,.10)',
              color: 'var(--text)',
              cursor: 'pointer',
            }}
          >
            Upgrade Now
          </button>
        </div>
      </div>
    </main>
  )
}