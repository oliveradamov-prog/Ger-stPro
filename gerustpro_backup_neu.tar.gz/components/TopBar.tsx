'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function TopBar() {
  const pathname = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [loadingUser, setLoadingUser] = useState(true)

  const hideOnRoutes = ['/login']
  const shouldHide = hideOnRoutes.includes(pathname || '')

  useEffect(() => {
    let active = true

    async function loadSession() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!active) return
        setEmail(session?.user?.email || '')
      } catch {
        if (!active) return
        setEmail('')
      } finally {
        if (active) setLoadingUser(false)
      }
    }

    loadSession()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setEmail(session?.user?.email || '')
      setLoadingUser(false)
    })

    return () => {
      active = false
      subscription.unsubscribe()
    }
  }, [])

  async function logout() {
    try {
      await supabase.auth.signOut()
    } catch {}
    window.location.href = '/login'
  }

  if (shouldHide) return null

  return (
    <>
      <div className="topbar">
        <div className="left">
          <button
            className="menuBtn"
            onClick={() => setMenuOpen((v) => !v)}
            type="button"
            aria-label="Menü öffnen"
          >
            ☰
          </button>

          <Link href="/" className="brand">
            <img src="/gerustpro-logo.png" alt="GerüstPro" className="logo" />
            <span className="brandText">GerüstPro</span>
          </Link>
        </div>

        <div className="right">
          {!loadingUser && email ? <div className="email">{email}</div> : null}

          {!loadingUser && email ? (
            <button onClick={logout} className="logout" type="button">
              Abmelden
            </button>
          ) : !loadingUser ? (
            <Link href="/login" className="loginLink">
              Anmelden
            </Link>
          ) : null}
        </div>
      </div>

      {menuOpen && (
        <div className="mobileMenu">
          <Link href="/projects" onClick={() => setMenuOpen(false)}>
            Projekte
          </Link>

          {!loadingUser && email ? (
            <button
              onClick={async () => {
                setMenuOpen(false)
                await logout()
              }}
              type="button"
            >
              Abmelden
            </button>
          ) : !loadingUser ? (
            <Link href="/login" onClick={() => setMenuOpen(false)}>
              Anmelden
            </Link>
          ) : null}
        </div>
      )}

      <style jsx>{`
        .topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          border-bottom: 1px solid var(--border);
          background: rgba(255, 255, 255, 0.03);
          backdrop-filter: blur(6px);
          position: sticky;
          top: 0;
          z-index: 40;
        }

        .left {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
          min-width: 0;
        }

        .logo {
          width: 28px;
          height: 28px;
          object-fit: contain;
          flex: 0 0 auto;
        }

        .brandText {
          font-weight: 950;
          font-size: 18px;
          color: var(--text);
          line-height: 1;
          white-space: nowrap;
        }

        .menuBtn {
          font-size: 24px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid var(--border);
          border-radius: 14px;
          cursor: pointer;
          color: var(--text);
          width: 44px;
          height: 44px;
          flex: 0 0 auto;
        }

        .right {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
          max-width: 56%;
        }

        .email {
          font-size: 13px;
          color: var(--muted);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 180px;
          font-weight: 800;
        }

        .logout,
        .loginLink {
          border: 1px solid var(--border);
          background: var(--chip);
          color: var(--text);
          padding: 10px 14px;
          border-radius: 12px;
          cursor: pointer;
          font-weight: 900;
          text-decoration: none;
          white-space: nowrap;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 44px;
        }

        .mobileMenu {
          display: flex;
          flex-direction: column;
          padding: 12px 16px 14px;
          border-bottom: 1px solid var(--border);
          background: rgba(255, 255, 255, 0.03);
          gap: 10px;
        }

        .mobileMenu a,
        .mobileMenu button {
          text-decoration: none;
          font-weight: 900;
          color: var(--text);
          border: 1px solid var(--border);
          background: var(--chip);
          border-radius: 12px;
          min-height: 44px;
          padding: 10px 12px;
          text-align: left;
        }

        @media (max-width: 720px) {
          .email {
            display: none;
          }

          .right {
            max-width: none;
          }

          .brandText {
            font-size: 17px;
          }
        }
      `}</style>
    </>
  )
}